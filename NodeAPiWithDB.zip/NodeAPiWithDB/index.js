const express = require('express')
const bodyParser = require('body-parser')
 const cors = require('cors')
const fs = require('fs')
const path = require('path')
 const morgan = require('morgan')
const router = require('./routes/route')

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(router);
//const routes  = require('./routes/route.js')(app,fs)

const server = app.listen(3000,()=>{
    console.log('listining on port %s...', server.address.port);
});
//app.use(cors())


// // parse application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded({ extended: true }));

// // parse application/json
// app.use(bodyParser.json());

// app.use(morgan('dev'));

// // create a write stream (in append mode)
// var accessLogStream = fs.createWriteStream(path.join(__dirname, '/logs/access.log'), { flags: 'a' });
 
// // setup the logger
// app.use(morgan('combined', { stream: accessLogStream }));

// app.use(router);

// app.get('/', function (req, res) {
//     res.send('Hello World!')
//   })

// const port = 3000

// app.listen(process.env.PORT || port , (err) => {
//   if(err)
// console.log('Unable to start the server!')
// else
// console.log('Server started running on : ' + port)
// })