const sql = require('mssql/msnodesqlv8')

const config = {

    driver: 'msnodesqlv8',
    connectionString:'Driver={SQL Server Native Client 11.0};Server={DESKTOP-ARCHANA};Database={DemoDB};Trusted_Connection={yes};'
    // user: 'sa',
    // password: '123456',
    // server: 'DESKTOP-ARCHANA',
    //  database: 'DemoDB',
    // options: {
    //     encrypt: false
    // }
}; 
const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log('Connected to MSSQL')
    return pool
  })
  .catch(err => console.log('Database Connection Failed! Bad Config: ', err))

module.exports = {
  sql, poolPromise
}