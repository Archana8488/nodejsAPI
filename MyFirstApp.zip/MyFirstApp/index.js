const express = require('express');
var bodyParser = require("body-parser");
const app = express();
const fs = require('fs');

// app.get('/', (req, res) => {
  // res.send('Hello World!')
// });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var routes = require("./routes/routes.js")(app,fs);

var server = app.listen(8000, function () {
    console.log("Listening on port %s...", server.address().port);
});

// app.listen(8000, () => {
  // console.log('Example app listening on port 8000!')
// });